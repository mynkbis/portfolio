import { useState } from "react";
import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
import NavBar from "./Navbar";

const SharedLayout = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <div className="flex h-screen overflow-hidden">
    <Sidebar />
    <div className="flex flex-col flex-1 overflow-x-auto">
      <NavBar/>
      {/* Show Loader if isLoading is true */}
      {/* {isLoading && <Loader />}
      <div className="px-12">
        <CustomTabs />
        <CustomSubTabs />
      </div> */}
      <main className="flex-1 overflow-auto no-scrollbar bg-botpulseOutletBg">
        <div className="min-h-[calc(100vh-150px)] flex flex-col bg-botpulseOutletBg">
          <div className="flex-1">
            <Outlet />
          </div>
          <div className="pb-2 pt-8 flex justify-end px-12 text-botpulseFooterText">
          </div>
        </div>
      </main>
    </div>
  </div>
  );
};

export default SharedLayout;
