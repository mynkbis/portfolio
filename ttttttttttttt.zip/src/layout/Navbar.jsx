// import { useState } from "react";
// import { Menu, X } from "lucide-react";
// import { motion } from "framer-motion";

// export default function Navbar() {
//   const [isOpen, setIsOpen] = useState(false);

//   return (
//     <nav className="bg-blue-600 p-4 shadow-md">
//       <div className="container mx-auto flex justify-between items-center">
//         <h1 className="text-white text-2xl font-bold">Brand</h1>
        
//         {/* Desktop Menu */}
//         <ul className="hidden md:flex space-x-6 text-white text-lg">
//           <li className="hover:text-gray-300 cursor-pointer">Home</li>
//           <li className="hover:text-gray-300 cursor-pointer">About</li>
//           <li className="hover:text-gray-300 cursor-pointer">Services</li>
//           <li className="hover:text-gray-300 cursor-pointer">Contact</li>
//         </ul>
// {/*  */}
//         {/* Mobile Menu Toggle */}
//         <button 
//           className="md:hidden text-white" 
//           onClick={() => setIsOpen(!isOpen)}
//         >
//           {isOpen ? <X size={28} /> : <Menu size={28} />}
//         </button>
//       </div>

//       {/* Mobile Menu */}
//       {isOpen && (
//         <motion.ul 
//           initial={{ opacity: 0, y: -10 }}
//           animate={{ opacity: 1, y: 0 }}
//           exit={{ opacity: 0, y: -10 }}
//           className="md:hidden flex flex-col space-y-4 bg-blue-700 p-4 text-white text-lg"
//         >
//           <li className="hover:text-gray-300 cursor-pointer">Home</li>
//           <li className="hover:text-gray-300 cursor-pointer">About</li>
//           <li className="hover:text-gray-300 cursor-pointer">Services</li>
//           <li className="hover:text-gray-300 cursor-pointer">Contact</li>
//         </motion.ul>
//       )}
//     </nav>
//   );
// }



import { useEffect, useRef, useState } from "react";
import { Input } from "../components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";
import { ChevronDown, Eye, LogOut } from "lucide-react";
import { useNavigate } from "react-router-dom";
// import { useDispatch, useSelector } from "react-redux";


const NavBar = () => {
//   const dispatch = useDispatch();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [isSearchVisible, setIsSearchVisible] = useState(false);
//   const { navTitle } = useSelector((state) => state.navTitle);
//   const { user } = useSelector((state) => state.auth);
//   const { profile } = useSelector((state) => state.profileAdmin);

  const navigate = useNavigate();
  const dropdownRef = useRef(null);

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const handleLogout = () => {
    // dispatch(logout());
    // navigate("/auth/login");
  };

  const toggleSearch = () => {
    setIsSearchVisible(!isSearchVisible);
  };

  const handleProfile = () => {
    navigate("/admin/myaccount");
    setDropdownOpen(false);
  };

//   useEffect(() => {
//     dispatch(fetchUserProfile(user?._id));
//     if (profile?.user_status === "inactive" || profile?.is_profile_deleted ) {
//       handleLogout()
//       dispatch(clearProfile())
//     }
//   }, [dispatch, user ,profile?.user_status ]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleOutsideClick = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener("click", handleOutsideClick);
    return () => {
      document.removeEventListener("click", handleOutsideClick);
    };
  }, []);

  return (
    <header className="flex items-center justify-between  px-6 h-20 bg-white relative z-30">
      <div className="absolute inset-0 bg-botpulseNavbarBg"></div>
      <h1 className="text-botpulseNavText text-2xl z-10 whitespace-nowrap">
        {/* {navTitle && navTitle} */}
      </h1>
      <div className="relative flex items-center justify-end w-[82%]">
        <div
          className={`transition-all duration-300 ease-in-out overflow-hidden ${
            isSearchVisible ? "w-96" : "w-0"
          }`}
        >
          <div className="relative flex items-center w-full">
            <Input
              type="text"
              placeholder="Search"
              className="common-font rounded-full border border-botpulseSearchBorder text-white focus-visible:ring-none focus-visible:ring-none focus-visible:border-botpulseSearchBorder"
            />
            <div className="absolute right-12 inset-y-0 w-px bg-botpulseSearchBorder"></div>
            <button
              type="submit"
              className="absolute inset-y-0 text-white right-1 flex items-center justify-center w-10 group hover:text-botpulseOrange"
              aria-label="Toggle Search"
              onClick={toggleSearch}
            >
              {/* <SearchSVG className="text-botpulseSearchIcon h-5 w-5 group-hover:text-white" /> */}
            </button>
          </div>
        </div>
        <button
          type="button"
          onClick={toggleSearch}
          className={`flex items-center justify-center text-white border border-2 ${
            !isSearchVisible
              ? "w-10 h-10 transition-all duration-300 ease-in-out"
              : "hidden "
          } rounded-full bg-transparent ml-2 group hover:bg-botpulseOrange hover:border-botpulseOrange `}
          aria-label="Toggle Search"
        >
          {/* <SearchSVG className="h-5 w-5 text-white" /> */}
        </button>
      </div>
      <div className="flex items-center z-10 pl-3">
        <button
          variant="ghost"
          size="icon"
          className="mr-4 bg-transparent rounded-full border w-10 h-10 border border-2 group hover:bg-botpulseOrange hover:border-botpulseOrange"
        >
          {/* <NotificationSVG width={18} /> */}
          <span className="sr-only">Notifications</span>
        </button>
        <Avatar>
          {/* <AvatarImage alt="Profile picture"  src={`${import.meta.env.VITE_AWS_BUCKET_URL}/${profile?.image}`}  /> */}
          <AvatarImage
            // src={profile?.image}
            alt="User"
            className="rounded-full bg-white"
          />
          <AvatarFallback>
            {" "}
            {/* {profile?.userName
              ? profile.userName
                  .split(" ")
                  .map((word) => word[0])
                  .join("")
                  .toUpperCase()
              : ""} */}
          </AvatarFallback>
        </Avatar>
        <div className="relative" ref={dropdownRef}>
          {dropdownOpen && (
            <div className="absolute -right-2 mt-8 w-42 bg-white border border-gray-200 rounded-lg shadow-lg z-20">
              <ul className="">
                <li
                  className="px-4 py-2 hover:bg-botpulseOrange rounded-t-lg hover:text-white cursor-pointer flex gap-2 text-botpulseTableText group hover:text-white"
                  tabIndex={0}
                  onClick={() => handleProfile()}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      handleProfile();
                    }
                  }}                  
                >
                  <Eye className="h-4 w-4 mt-1" />
                  <span className="text-botpulseTableText group-hover:text-white whitespace-nowrap">
                    View Account
                  </span>
                </li>
                <li
                  className="px-4 py-2 hover:bg-botpulseOrange rounded-b-lg hover:text-white cursor-pointer flex gap-2 text-botpulseTableText group hover:text-white"
                  onClick={()=>{handleLogout(); localStorage.removeItem("filters")}}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                        handleLogout(); localStorage.removeItem("filters")
                    }
                  }}
                >
                  {/* <LogOut className="h-4 w-4 mt-1" /> */}
                  <span className="text-botpulseTableText group-hover:text-white">
                    Logout
                  </span>
                </li>
              </ul>
            </div>
          )}
          <button
            onClick={toggleDropdown}
            className="flex items-center focus:outline-none"
          >
            <span className="ml-2 text-sm font-medium text-white whitespace-nowrap">
              {/* {profile?.userName
                ? profile.userName.length <= 15
                  ? profile.userName
                  : `${profile.userName.substring(0, 15)}...`
                : "User"} */}
            </span>
          
          </button>
        </div>
      </div>
    </header>
  );
};

export default NavBar;

