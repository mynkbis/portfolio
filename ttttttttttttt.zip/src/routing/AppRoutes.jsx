import { useEffect } from "react";
import { Route, Routes } from "react-router-dom";
import SharedLayout from "../layout/SharedLayout";
// import PrivateRoutes from "../HOC/PrivateRoutes";

const AppRoutes = () => {
    // const allPermissions = useSelector((state) => state.auth.allPermissions);
    // const dispatch = useDispatch()
    // useEffect(()=>{
    // dispatch(fetchAllPermissions())
    // },[dispatch])
    // const checkPermission = (permissionKey) =>
    //   allPermissions[permissionKey]?.length > 0;
  
    return (
      <Routes>
        <Route path="/" element={<SharedLayout />} />
      
      </Routes>
    );
  };
  
  export default AppRoutes;